from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests

P = Path.home() / "Research/PD_MCI_Network"

# ============================================================
# LOAD DATA
# ============================================================

fc = pd.read_csv(
    P / "results/network_connectivity_28.csv"
)

cov = pd.read_csv(
    P / "results/final_sample_covariates.csv"
)

df = fc.merge(
    cov[
        [
            "Subject",
            "age",
            "sex",
            "Mean_FD_mm",
        ]
    ],
    on="Subject",
    how="inner",
)

print("Subjects in regression:", len(df))

print("\nGroup counts:")
print(df["Group"].value_counts())

# Explicit reference categories
df["Group"] = pd.Categorical(
    df["Group"],
    categories=[
        "Control",
        "PD-NC",
        "PD-MCI",
    ],
)

df["sex"] = pd.Categorical(
    df["sex"],
    categories=["F", "M"],
)

# Center continuous covariates
df["Age_c"] = (
    df["age"] - df["age"].mean()
)

df["FD_c"] = (
    df["Mean_FD_mm"]
    - df["Mean_FD_mm"].mean()
)

# 28 network measures
measures = [
    c for c in fc.columns
    if c not in ["Subject", "Group"]
]

print("\nNetwork measures:", len(measures))

results = []

# ============================================================
# FIT 28 MODELS
# ============================================================

for measure in measures:

    formula = (
        f'Q("{measure}") ~ '
        'C(Group, Treatment(reference="Control")) + '
        'Age_c + '
        'C(sex, Treatment(reference="F")) + '
        'FD_c'
    )

    model = smf.ols(
        formula,
        data=df,
    ).fit()

    term_nc = (
        'C(Group, Treatment(reference="Control"))'
        '[T.PD-NC]'
    )

    term_mci = (
        'C(Group, Treatment(reference="Control"))'
        '[T.PD-MCI]'
    )

    # --------------------------------------------------------
    # PD-NC vs Control
    # --------------------------------------------------------

    est_nc = model.params[term_nc]
    se_nc = model.bse[term_nc]
    p_nc = model.pvalues[term_nc]

    ci_nc = model.conf_int().loc[term_nc]

    # --------------------------------------------------------
    # PD-MCI vs Control
    # --------------------------------------------------------

    est_mci = model.params[term_mci]
    se_mci = model.bse[term_mci]
    p_mci = model.pvalues[term_mci]

    ci_mci = model.conf_int().loc[term_mci]

    # --------------------------------------------------------
    # PD-MCI vs PD-NC
    # --------------------------------------------------------

    names = list(model.params.index)

    contrast = np.zeros(len(names))

    contrast[
        names.index(term_mci)
    ] = 1

    contrast[
        names.index(term_nc)
    ] = -1

    test = model.t_test(contrast)

    est_mci_nc = float(
        np.asarray(test.effect).item()
    )

    se_mci_nc = float(
        np.asarray(test.sd).item()
    )

    p_mci_nc = float(
        np.asarray(test.pvalue).item()
    )

    ci_mci_nc = (
        np.asarray(test.conf_int())
        .reshape(-1)
    )

    results.append(
        {
            "Measure": measure,

            "PDNC_vs_Control_Est": est_nc,
            "PDNC_vs_Control_SE": se_nc,
            "PDNC_vs_Control_CI_low":
                ci_nc.iloc[0],
            "PDNC_vs_Control_CI_high":
                ci_nc.iloc[1],
            "PDNC_vs_Control_p": p_nc,

            "PDMCI_vs_Control_Est": est_mci,
            "PDMCI_vs_Control_SE": se_mci,
            "PDMCI_vs_Control_CI_low":
                ci_mci.iloc[0],
            "PDMCI_vs_Control_CI_high":
                ci_mci.iloc[1],
            "PDMCI_vs_Control_p": p_mci,

            "PDMCI_vs_PDNC_Est":
                est_mci_nc,
            "PDMCI_vs_PDNC_SE":
                se_mci_nc,
            "PDMCI_vs_PDNC_CI_low":
                ci_mci_nc[0],
            "PDMCI_vs_PDNC_CI_high":
                ci_mci_nc[1],
            "PDMCI_vs_PDNC_p":
                p_mci_nc,

            "Age_p":
                model.pvalues["Age_c"],

            "Motion_p":
                model.pvalues["FD_c"],

            "Model_R2":
                model.rsquared,
        }
    )

res = pd.DataFrame(results)

# ============================================================
# FDR CORRECTION
# ============================================================

contrasts = [
    "PDNC_vs_Control",
    "PDMCI_vs_Control",
    "PDMCI_vs_PDNC",
]

for prefix in contrasts:

    reject, q, _, _ = multipletests(
        res[f"{prefix}_p"],
        alpha=0.05,
        method="fdr_bh",
    )

    res[f"{prefix}_q"] = q
    res[f"{prefix}_FDR_sig"] = reject

# ============================================================
# SAVE COMPLETE RESULTS
# ============================================================

outfile = (
    P /
    "results/network_statistics_adjusted.csv"
)

res.to_csv(
    outfile,
    index=False,
)

# ============================================================
# DISPLAY TOP RESULTS
# ============================================================

titles = {
    "PDNC_vs_Control":
        "PD-NC vs Control",

    "PDMCI_vs_Control":
        "PD-MCI vs Control",

    "PDMCI_vs_PDNC":
        "PD-MCI vs PD-NC",
}

for prefix in contrasts:

    print("\n" + "=" * 78)
    print(titles[prefix])
    print("=" * 78)

    cols = [
        "Measure",
        f"{prefix}_Est",
        f"{prefix}_CI_low",
        f"{prefix}_CI_high",
        f"{prefix}_p",
        f"{prefix}_q",
        f"{prefix}_FDR_sig",
    ]

    temp = (
        res[cols]
        .sort_values(f"{prefix}_p")
    )

    print(
        temp.head(10)
        .round(4)
        .to_string(index=False)
    )

    print(
        "\nFDR-significant:",
        int(
            temp[
                f"{prefix}_FDR_sig"
            ].sum()
        ),
        "/ 28",
    )

print("\nComplete results saved to:")
print(outfile)
