from pathlib import Path
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

P = Path.home() / "Research/PD_MCI_Network"
NBS = P / "results/NBS_PDMCI_Control_directional"
INPUT = P / "results/NBS_PDMCI_Control"

THRESHOLD = 3.1
N_PERM = 5000
SEED = 20261005

rng = np.random.default_rng(SEED)
NBS.mkdir(parents=True, exist_ok=True)

# ============================================================
# LOAD DATA
# ============================================================

mats = np.load(INPUT / "fc_z_matrices.npy")
X = np.load(INPUT / "design_matrix.npy")
subjects = pd.read_csv(INPUT / "subjects_covariates.csv")

n, nroi, _ = mats.shape

iu = np.triu_indices(nroi, k=1)
Y = mats[:, iu[0], iu[1]]

print("Subjects:", n)
print("Control:", (subjects["Group"] == "Control").sum())
print("PD-MCI:", (subjects["Group"] == "PD-MCI").sum())
print("ROIs:", nroi)
print("Edges:", Y.shape[1])
print("Threshold:", THRESHOLD)
print("Permutations:", N_PERM)

# Design:
# Intercept, Group(PD-MCI=1), Age, Sex, FD
group_col = 1

X0 = np.delete(X, group_col, axis=1)

# ============================================================
# OBSERVED EDGEWISE REGRESSION
# ============================================================

XtX_inv = np.linalg.inv(X.T @ X)

B = XtX_inv @ X.T @ Y
resid = Y - X @ B

df_resid = n - np.linalg.matrix_rank(X)

sigma2 = np.sum(resid**2, axis=0) / df_resid

se_group = np.sqrt(
    sigma2 * XtX_inv[group_col, group_col]
)

t_obs = B[group_col] / se_group

print("Residual df:", df_resid)
print("Maximum t:", t_obs.max())
print("Minimum t:", t_obs.min())

# ============================================================
# COMPONENT FINDER
# ============================================================

def find_components(t_values, threshold, direction):

    if direction == "positive":
        mask = t_values > threshold

    elif direction == "negative":
        mask = t_values < -threshold

    else:
        raise ValueError(direction)

    edge_i = iu[0][mask]
    edge_j = iu[1][mask]

    if len(edge_i) == 0:
        return []

    adjacency = np.zeros(
        (nroi, nroi),
        dtype=np.uint8
    )

    adjacency[edge_i, edge_j] = 1
    adjacency[edge_j, edge_i] = 1

    _, labels = connected_components(
        csr_matrix(adjacency),
        directed=False,
        return_labels=True
    )

    components = []

    for component_id in np.unique(labels):

        nodes = np.where(
            labels == component_id
        )[0]

        if len(nodes) < 2:
            continue

        node_mask = np.zeros(
            nroi,
            dtype=bool
        )

        node_mask[nodes] = True

        component_edge_mask = (
            mask
            & node_mask[iu[0]]
            & node_mask[iu[1]]
        )

        edge_indices = np.where(
            component_edge_mask
        )[0]

        if len(edge_indices) == 0:
            continue

        components.append({
            "nodes": nodes,
            "edge_indices": edge_indices,
            "extent": len(edge_indices)
        })

    components.sort(
        key=lambda x: x["extent"],
        reverse=True
    )

    return components

# ============================================================
# OBSERVED COMPONENTS
# ============================================================

obs_pos = find_components(
    t_obs,
    THRESHOLD,
    "positive"
)

obs_neg = find_components(
    t_obs,
    THRESHOLD,
    "negative"
)

print("\nObserved POSITIVE components (PD-MCI > Control):")

if not obs_pos:
    print("None")
else:
    for i, comp in enumerate(obs_pos, 1):
        print(
            f"Component {i}: "
            f"{len(comp['nodes'])} nodes, "
            f"{comp['extent']} edges"
        )

print("\nObserved NEGATIVE components (PD-MCI < Control):")

if not obs_neg:
    print("None")
else:
    for i, comp in enumerate(obs_neg, 1):
        print(
            f"Component {i}: "
            f"{len(comp['nodes'])} nodes, "
            f"{comp['extent']} edges"
        )

# ============================================================
# FREEDMAN-LANE
# ============================================================

X0_inv = np.linalg.pinv(X0)

B0 = X0_inv @ Y
Yhat0 = X0 @ B0
E0 = Y - Yhat0

# One null distribution for each direction.
max_pos_null = np.zeros(
    N_PERM,
    dtype=int
)

max_neg_null = np.zeros(
    N_PERM,
    dtype=int
)

print("\nStarting directional permutations...")

for p in range(N_PERM):

    perm = rng.permutation(n)

    Yperm = Yhat0 + E0[perm, :]

    Bp = XtX_inv @ X.T @ Yperm

    resid_p = Yperm - X @ Bp

    sigma2_p = (
        np.sum(resid_p**2, axis=0)
        / df_resid
    )

    se_p = np.sqrt(
        sigma2_p
        * XtX_inv[group_col, group_col]
    )

    t_perm = (
        Bp[group_col] / se_p
    )

    pos = find_components(
        t_perm,
        THRESHOLD,
        "positive"
    )

    neg = find_components(
        t_perm,
        THRESHOLD,
        "negative"
    )

    if pos:
        max_pos_null[p] = pos[0]["extent"]

    if neg:
        max_neg_null[p] = neg[0]["extent"]

    if (p + 1) % 500 == 0:
        print(
            f"{p + 1}/{N_PERM} permutations complete"
        )

# ============================================================
# COMPONENT RESULTS
# ============================================================

rows = []

def save_results(components, direction, null):

    for i, comp in enumerate(components, 1):

        extent = comp["extent"]

        p_fwe = (
            1
            + np.sum(null >= extent)
        ) / (N_PERM + 1)

        edge_indices = comp["edge_indices"]

        edge_rows = iu[0][edge_indices]
        edge_cols = iu[1][edge_indices]

        component_t = t_obs[edge_indices]

        rows.append({
            "Direction": direction,
            "Component": i,
            "Nodes": len(comp["nodes"]),
            "Edges": extent,
            "FWE_p": p_fwe,
            "Mean_t": np.mean(component_t),
            "Min_t": np.min(component_t),
            "Max_t": np.max(component_t)
        })

        prefix = (
            "positive"
            if direction == "PD-MCI > Control"
            else "negative"
        )

        np.save(
            NBS /
            f"{prefix}_component_{i}_nodes.npy",
            comp["nodes"]
        )

        np.save(
            NBS /
            f"{prefix}_component_{i}_edges.npy",
            np.column_stack(
                [edge_rows, edge_cols]
            )
        )

save_results(
    obs_pos,
    "PD-MCI > Control",
    max_pos_null
)

save_results(
    obs_neg,
    "PD-MCI < Control",
    max_neg_null
)

results = pd.DataFrame(rows)

results.to_csv(
    NBS / "directional_nbs_results.csv",
    index=False
)

np.save(
    NBS / "observed_t.npy",
    t_obs
)

np.save(
    NBS / "positive_null_max_extent.npy",
    max_pos_null
)

np.save(
    NBS / "negative_null_max_extent.npy",
    max_neg_null
)

# ============================================================
# DISPLAY RESULTS
# ============================================================

print("\n" + "=" * 70)
print("DIRECTIONAL NBS RESULTS")
print("=" * 70)

if len(results) == 0:
    print("No suprathreshold components.")

else:
    print(
        results
        .round(4)
        .to_string(index=False)
    )

    print("\nFWE-significant components:")

    sig = results[
        results["FWE_p"] < 0.05
    ]

    if len(sig) == 0:
        print("None")
    else:
        print(
            sig.round(4).to_string(
                index=False
            )
        )

print("\nPOSITIVE null distribution:")
print(
    "Median max extent:",
    np.median(max_pos_null)
)
print(
    "95th percentile:",
    np.percentile(max_pos_null, 95)
)

print("\nNEGATIVE null distribution:")
print(
    "Median max extent:",
    np.median(max_neg_null)
)
print(
    "95th percentile:",
    np.percentile(max_neg_null, 95)
)

print("\nSaved to:")
print(NBS)
