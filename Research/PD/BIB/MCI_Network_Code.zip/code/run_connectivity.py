from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import nilearn
from nilearn import datasets
from nilearn.interfaces.fmriprep import load_confounds
from nilearn.maskers import NiftiLabelsMasker
from nilearn.connectome import ConnectivityMeasure

# ============================================================
# SETTINGS
# ============================================================

P = Path.home() / "Research/PD_MCI_Network"

DERIV = P / "derivatives"
RESULTS = P / "results"
OUTROOT = RESULTS / "connectivity"

QCFILE = RESULTS / "nilearn_retained_volume_qc.csv"

TR = 2.0
MIN_VOLUMES = 150
FD_THRESHOLD = 0.5
DVARS_THRESHOLD = 1.5

OUTROOT.mkdir(parents=True, exist_ok=True)

print("Nilearn version:", nilearn.__version__)

# ============================================================
# LOAD QC TABLE
# ============================================================

qc = pd.read_csv(QCFILE)

if qc["Pass_5min"].dtype == bool:
    passed = qc[qc["Pass_5min"]].copy()
else:
    passed = qc[
        qc["Pass_5min"].astype(str).str.lower() == "true"
    ].copy()

print("\nSubjects passing QC:", len(passed))

print("\nBy group:")
print(passed["Group"].value_counts())

# ============================================================
# LOAD SCHAEFER-200 ATLAS
# ============================================================

atlas = datasets.fetch_atlas_schaefer_2018(
    n_rois=200,
    yeo_networks=7,
    resolution_mm=2,
)

labels = [
    x.decode() if isinstance(x, bytes) else str(x)
    for x in atlas.labels
]

roi_labels = labels[1:]

if len(roi_labels) != 200:
    raise RuntimeError(
        f"Expected 200 ROI labels, found {len(roi_labels)}"
    )

with open(OUTROOT / "schaefer200_labels.txt", "w") as f:
    for label in roi_labels:
        f.write(label + "\n")

# ============================================================
# CONNECTIVITY ESTIMATOR
# ============================================================

correlation_measure = ConnectivityMeasure(
    kind="correlation",
    standardize="zscore_sample",
)

summary_rows = []

# ============================================================
# PROCESS ALL QC-PASSING SUBJECTS
# ============================================================

for i, row in enumerate(passed.itertuples(index=False), start=1):

    SUB = row.Subject
    GROUP = row.Group

    print("\n" + "=" * 65)
    print(f"[{i}/{len(passed)}] Processing {SUB} ({GROUP})")
    print("=" * 65)

    bold = (
        DERIV / f"sub-{SUB}" / "func" /
        f"sub-{SUB}_task-rest_space-MNI152NLin2009cAsym_res-2_desc-preproc_bold.nii.gz"
    )

    if not bold.exists():
        print("ERROR: BOLD file missing")

        summary_rows.append({
            "Subject": SUB,
            "Group": GROUP,
            "Status": "MISSING_BOLD",
        })
        continue

    outdir = OUTROOT / f"sub-{SUB}"
    outdir.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------
    # LOAD CONFOUNDS + CENSORING MASK
    # --------------------------------------------------------

    confounds, sample_mask = load_confounds(
        str(bold),
        strategy=("motion", "high_pass", "compcor", "scrub"),
        motion="full",
        compcor="anat_combined",
        scrub=0,
        fd_threshold=FD_THRESHOLD,
        std_dvars_threshold=DVARS_THRESHOLD,
    )

    if sample_mask is None:
        retained = len(confounds)
    else:
        retained = len(sample_mask)

    retained_minutes = retained * TR / 60.0

    print("Retained volumes:", retained)
    print("Retained minutes:", round(retained_minutes, 2))

    if retained < MIN_VOLUMES:
        print("SKIPPED: fewer than 150 retained volumes.")

        summary_rows.append({
            "Subject": SUB,
            "Group": GROUP,
            "Status": "FAILED_RETENTION",
            "Retained_volumes": retained,
            "Retained_minutes": retained_minutes,
        })
        continue

    # --------------------------------------------------------
    # DENOISING + SCHAEFER-200 EXTRACTION
    # --------------------------------------------------------

    masker = NiftiLabelsMasker(
        labels_img=atlas.maps,
        labels=atlas.labels,
        standardize="zscore_sample",
        detrend=True,
        low_pass=0.08,
        high_pass=None,
        t_r=TR,
        resampling_target="data",
        verbose=0,
    )

    with warnings.catch_warnings():
        warnings.simplefilter("default")

        timeseries = masker.fit_transform(
            str(bold),
            confounds=confounds,
            sample_mask=sample_mask,
        )

    print("Time-series shape:", timeseries.shape)

    # --------------------------------------------------------
    # TIME-SERIES QC
    # --------------------------------------------------------

    if timeseries.shape[1] != 200:
        raise RuntimeError(
            f"{SUB}: expected 200 ROIs, "
            f"found {timeseries.shape[1]}"
        )

    if np.isnan(timeseries).any():
        raise RuntimeError(
            f"{SUB}: NaN detected in ROI time series"
        )

    if np.isinf(timeseries).any():
        raise RuntimeError(
            f"{SUB}: Inf detected in ROI time series"
        )

    # --------------------------------------------------------
    # PEARSON FUNCTIONAL CONNECTIVITY
    # --------------------------------------------------------

    fc_r = correlation_measure.fit_transform(
        [timeseries]
    )[0]

    # --------------------------------------------------------
    # MATRIX QC
    # --------------------------------------------------------

    symmetric = np.allclose(fc_r, fc_r.T)
    diagonal_ok = np.allclose(np.diag(fc_r), 1)
    nan_count = int(np.isnan(fc_r).sum())
    inf_count = int(np.isinf(fc_r).sum())

    if not symmetric:
        raise RuntimeError(
            f"{SUB}: FC matrix is not symmetric"
        )

    if not diagonal_ok:
        raise RuntimeError(
            f"{SUB}: FC diagonal is not 1"
        )

    if nan_count != 0:
        raise RuntimeError(
            f"{SUB}: FC contains NaN values"
        )

    if inf_count != 0:
        raise RuntimeError(
            f"{SUB}: FC contains infinite values"
        )

    # --------------------------------------------------------
    # FISHER r-to-z
    # --------------------------------------------------------

    fc_clip = np.clip(
        fc_r,
        -0.999999,
        0.999999,
    )

    fc_z = np.arctanh(fc_clip)

    # Diagonal is excluded from edge analyses.
    np.fill_diagonal(fc_z, 0)

    # --------------------------------------------------------
    # SAVE SUBJECT OUTPUTS
    # --------------------------------------------------------

    np.save(outdir / "timeseries.npy", timeseries)
    np.save(outdir / "fc_r.npy", fc_r)
    np.save(outdir / "fc_z.npy", fc_z)

    upper = fc_r[
        np.triu_indices_from(fc_r, k=1)
    ]

    summary_rows.append({
        "Subject": SUB,
        "Group": GROUP,
        "Status": "OK",
        "Retained_volumes": retained,
        "Retained_minutes": retained_minutes,
        "N_ROIs": timeseries.shape[1],
        "Mean_FC_r": np.mean(upper),
        "Median_FC_r": np.median(upper),
        "Min_FC_r": np.min(upper),
        "Max_FC_r": np.max(upper),
        "Symmetric": symmetric,
        "Diagonal_OK": diagonal_ok,
        "NaN_count": nan_count,
        "Inf_count": inf_count,
    })

    # Save progress after every successful subject.
    summary = pd.DataFrame(summary_rows)

    summary.to_csv(
        RESULTS / "connectivity_processing_summary.csv",
        index=False,
    )

    print("FC matrix:", fc_r.shape)
    print("Mean FC:", round(float(np.mean(upper)), 4))
    print("SUCCESS:", SUB)

# ============================================================
# FINAL SUMMARY
# ============================================================

summary = pd.DataFrame(summary_rows)

summary.to_csv(
    RESULTS / "connectivity_processing_summary.csv",
    index=False,
)

print("\n" + "=" * 65)
print("CONNECTIVITY PROCESSING COMPLETE")
print("=" * 65)

print("\nStatus counts:")
print(summary["Status"].value_counts())

ok = summary[summary["Status"] == "OK"]

print("\nSuccessful subjects by group:")
print(ok["Group"].value_counts())

print("\nSummary saved to:")
print(
    RESULTS / "connectivity_processing_summary.csv"
)
