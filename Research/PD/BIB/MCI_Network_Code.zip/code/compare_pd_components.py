from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

P = Path.home() / "Research/PD_MCI_Network"

PDNC = P / "results/NBS_PDNC_Control"
PDMCI = P / "results/NBS_PDMCI_Control"

PDNC_DIR = P / "results/NBS_PDNC_Control_directional"
PDMCI_DIR = P / "results/NBS_PDMCI_Control_directional"

OUT = P / "results/PD_component_comparison"
OUT.mkdir(parents=True, exist_ok=True)

# ============================================================
# FUNCTION: ADJUSTED GROUP EFFECT FOR ALL 19,900 EDGES
# ============================================================

def edge_effects(input_dir):

    mats = np.load(
        input_dir / "fc_z_matrices.npy"
    )

    X = np.load(
        input_dir / "design_matrix.npy"
    )

    n, nroi, _ = mats.shape

    iu = np.triu_indices(nroi, k=1)

    Y = mats[:, iu[0], iu[1]]

    # Column 1 = group effect
    XtX_inv = np.linalg.inv(X.T @ X)

    B = XtX_inv @ X.T @ Y

    beta = B[1]

    resid = Y - X @ B

    df_resid = (
        n - np.linalg.matrix_rank(X)
    )

    sigma2 = (
        np.sum(resid ** 2, axis=0)
        / df_resid
    )

    se = np.sqrt(
        sigma2 * XtX_inv[1, 1]
    )

    t = beta / se

    return beta, t, iu


beta_nc, t_nc, iu_nc = edge_effects(PDNC)
beta_mci, t_mci, iu_mci = edge_effects(PDMCI)

if not (
    np.array_equal(iu_nc[0], iu_mci[0])
    and np.array_equal(iu_nc[1], iu_mci[1])
):
    raise RuntimeError(
        "Edge ordering differs."
    )

print("Edges:", len(beta_nc))

# ============================================================
# EFFECT CORRELATION
# ============================================================

r_beta, p_beta = pearsonr(
    beta_nc,
    beta_mci
)

rho_beta, p_rho = spearmanr(
    beta_nc,
    beta_mci
)

r_t, p_t = pearsonr(
    t_nc,
    t_mci
)

print("\n========================================")
print("WHOLE-CONNECTOME EFFECT CONVERGENCE")
print("========================================")

print(
    "Pearson correlation of adjusted betas:",
    round(r_beta, 4)
)

print(
    "Spearman correlation of adjusted betas:",
    round(rho_beta, 4)
)

print(
    "Pearson correlation of t statistics:",
    round(r_t, 4)
)

print("\nDirection agreement:")

same_direction = np.mean(
    np.sign(beta_nc)
    == np.sign(beta_mci)
)

both_negative = np.mean(
    (beta_nc < 0)
    & (beta_mci < 0)
)

both_positive = np.mean(
    (beta_nc > 0)
    & (beta_mci > 0)
)

print(
    "Same sign:",
    round(100 * same_direction, 2),
    "%"
)

print(
    "Both negative:",
    round(100 * both_negative, 2),
    "%"
)

print(
    "Both positive:",
    round(100 * both_positive, 2),
    "%"
)

# ============================================================
# LOAD NEGATIVE NBS COMPONENTS
# ============================================================

edges_nc = np.load(
    PDNC_DIR /
    "negative_component_1_edges.npy"
)

edges_mci = np.load(
    PDMCI_DIR /
    "negative_component_1_edges.npy"
)

nodes_nc = np.load(
    PDNC_DIR /
    "negative_component_1_nodes.npy"
)

nodes_mci = np.load(
    PDMCI_DIR /
    "negative_component_1_nodes.npy"
)

# Convert edges to unordered tuple sets
set_nc = {
    tuple(sorted(map(int, edge)))
    for edge in edges_nc
}

set_mci = {
    tuple(sorted(map(int, edge)))
    for edge in edges_mci
}

intersection = (
    set_nc & set_mci
)

union = (
    set_nc | set_mci
)

jaccard_edges = (
    len(intersection)
    / len(union)
)

# ============================================================
# NODE OVERLAP
# ============================================================

node_nc = set(
    map(int, nodes_nc)
)

node_mci = set(
    map(int, nodes_mci)
)

node_intersection = (
    node_nc & node_mci
)

node_union = (
    node_nc | node_mci
)

jaccard_nodes = (
    len(node_intersection)
    / len(node_union)
)

print("\n========================================")
print("NBS COMPONENT OVERLAP")
print("========================================")

print(
    "PD-NC negative component edges:",
    len(set_nc)
)

print(
    "PD-MCI negative component edges:",
    len(set_mci)
)

print(
    "Shared edges:",
    len(intersection)
)

print(
    "PD-NC edges also in PD-MCI:",
    round(
        100 * len(intersection)
        / len(set_nc),
        2
    ),
    "%"
)

print(
    "PD-MCI edges also in PD-NC:",
    round(
        100 * len(intersection)
        / len(set_mci),
        2
    ),
    "%"
)

print(
    "Edge Jaccard:",
    round(jaccard_edges, 4)
)

print("\nPD-NC nodes:", len(node_nc))
print("PD-MCI nodes:", len(node_mci))
print(
    "Shared nodes:",
    len(node_intersection)
)

print(
    "Node Jaccard:",
    round(jaccard_nodes, 4)
)

# ============================================================
# NETWORK LABELS
# ============================================================

labels = [
    x.strip()
    for x in (
        P /
        "results/connectivity/"
        "schaefer200_labels.txt"
    ).read_text().splitlines()
    if x.strip()
]

network_map = {
    "Vis": "Visual",
    "SomMot": "Somatomotor",
    "DorsAttn": "DorsalAttention",
    "SalVentAttn":
        "SalienceVentralAttention",
    "Limbic": "Limbic",
    "Cont": "Control",
    "Default": "DefaultMode",
}

network_order = [
    "Visual",
    "Somatomotor",
    "DorsalAttention",
    "SalienceVentralAttention",
    "Limbic",
    "Control",
    "DefaultMode",
]


def get_network(label):

    for key, value in network_map.items():

        if f"_{key}_" in label:
            return value

    raise RuntimeError(label)


def network_pair(edge):

    i, j = edge

    a = get_network(labels[i])
    b = get_network(labels[j])

    ordered = sorted(
        [a, b],
        key=lambda x:
            network_order.index(x)
    )

    return (
        ordered[0]
        + "__"
        + ordered[1]
    )


# ============================================================
# SHARED EDGE TABLE
# ============================================================

shared_rows = []

# Map edge pair to vector index
edge_index = {
    (int(i), int(j)): k
    for k, (i, j) in enumerate(
        zip(iu_nc[0], iu_nc[1])
    )
}

for i, j in sorted(intersection):

    key = (
        (i, j)
        if i < j
        else (j, i)
    )

    k = edge_index[key]

    shared_rows.append({
        "ROI1": labels[i],
        "ROI2": labels[j],
        "Network_pair":
            network_pair((i, j)),
        "PDNC_beta":
            beta_nc[k],
        "PDMCI_beta":
            beta_mci[k],
        "PDNC_t":
            t_nc[k],
        "PDMCI_t":
            t_mci[k],
    })

shared_df = pd.DataFrame(
    shared_rows
)

if len(shared_df) > 0:

    shared_df["mean_abs_t"] = (
        (
            np.abs(shared_df["PDNC_t"])
            + np.abs(shared_df["PDMCI_t"])
        )
        / 2
    )

    shared_df = shared_df.sort_values(
        "mean_abs_t",
        ascending=False
    )

shared_df.to_csv(
    OUT / "shared_nbs_edges.csv",
    index=False
)

# ============================================================
# NETWORK PAIRS AMONG SHARED EDGES
# ============================================================

if len(shared_df) > 0:

    pair_counts = (
        shared_df[
            "Network_pair"
        ]
        .value_counts()
        .reset_index()
    )

    pair_counts.columns = [
        "Network_pair",
        "Shared_edges"
    ]

else:

    pair_counts = pd.DataFrame(
        columns=[
            "Network_pair",
            "Shared_edges"
        ]
    )

pair_counts.to_csv(
    OUT /
    "shared_edge_network_pairs.csv",
    index=False
)

print("\n========================================")
print("NETWORK PAIRS AMONG SHARED EDGES")
print("========================================")

if len(pair_counts) == 0:
    print("No shared edges.")
else:
    print(
        pair_counts.head(20)
        .to_string(index=False)
    )

# ============================================================
# SAVE ALL EDGE EFFECTS
# ============================================================

all_edges = pd.DataFrame({
    "ROI1_index": iu_nc[0],
    "ROI2_index": iu_nc[1],
    "ROI1": [
        labels[i]
        for i in iu_nc[0]
    ],
    "ROI2": [
        labels[j]
        for j in iu_nc[1]
    ],
    "PDNC_beta":
        beta_nc,
    "PDMCI_beta":
        beta_mci,
    "PDNC_t":
        t_nc,
    "PDMCI_t":
        t_mci,
})

all_edges.to_csv(
    OUT /
    "all_edge_effect_comparison.csv",
    index=False
)

# ============================================================
# SUMMARY FILE
# ============================================================

summary = pd.DataFrame([{
    "Pearson_beta_r":
        r_beta,
    "Spearman_beta_rho":
        rho_beta,
    "Pearson_t_r":
        r_t,
    "Same_direction_pct":
        100 * same_direction,
    "Both_negative_pct":
        100 * both_negative,
    "Both_positive_pct":
        100 * both_positive,
    "PDNC_component_edges":
        len(set_nc),
    "PDMCI_component_edges":
        len(set_mci),
    "Shared_edges":
        len(intersection),
    "Edge_Jaccard":
        jaccard_edges,
    "PDNC_component_nodes":
        len(node_nc),
    "PDMCI_component_nodes":
        len(node_mci),
    "Shared_nodes":
        len(node_intersection),
    "Node_Jaccard":
        jaccard_nodes,
}])

summary.to_csv(
    OUT / "comparison_summary.csv",
    index=False
)

print("\n========================================")
print("TOP SHARED EDGES")
print("========================================")

if len(shared_df) == 0:
    print("No shared edges.")
else:
    print(
        shared_df[
            [
                "ROI1",
                "ROI2",
                "Network_pair",
                "PDNC_beta",
                "PDMCI_beta",
                "PDNC_t",
                "PDMCI_t",
            ]
        ]
        .head(15)
        .round(4)
        .to_string(index=False)
    )

print("\nSaved to:")
print(OUT)
