#!/bin/bash

set -u

PROJECT="$HOME/Research/PD_MCI_Network"
RAW="$PROJECT/raw/ds005892"
OUT="$PROJECT/derivatives"
WORK="$PROJECT/work"
LICENSE="$PROJECT/licenses/license.txt"
AWS="$HOME/.local/bin/aws"
IMAGE="nipreps/fmriprep:25.2.5"

mkdir -p "$WORK" "$OUT" "$PROJECT/results"

# Read ALL subjects directly from participants.tsv
tail -n +2 "$RAW/participants.tsv" | cut -f1 | while read -r PARTICIPANT
do
    # participants.tsv contains "sub-MJFxxx"
    SUB="${PARTICIPANT#sub-}"

    BOLD_OUT="$OUT/sub-$SUB/func/sub-${SUB}_task-rest_space-MNI152NLin2009cAsym_res-2_desc-preproc_bold.nii.gz"
    CONF_OUT="$OUT/sub-$SUB/func/sub-${SUB}_task-rest_desc-confounds_timeseries.tsv"
    REPORT_OUT="$OUT/sub-$SUB.html"

    echo
    echo "================================================"
    echo "Checking $SUB"
    echo "================================================"

    # Skip the 9 subjects already successfully completed
    if [ -f "$BOLD_OUT" ] && [ -f "$CONF_OUT" ] && [ -f "$REPORT_OUT" ]; then
        echo "$SUB already complete -> SKIPPING"
        continue
    fi

    echo "Downloading raw data for $SUB..."

    mkdir -p "$RAW/sub-$SUB"

    "$AWS" s3 cp \
      "s3://openneuro.org/ds005892/sub-${SUB}/" \
      "$RAW/sub-${SUB}/" \
      --recursive \
      --no-sign-request

    if [ $? -ne 0 ]; then
        echo "ERROR: Download failed for $SUB"
        exit 1
    fi

    # Add fieldmap IntendedFor association
    python3 - "$RAW" "$SUB" <<'PY'
import json
import sys
from pathlib import Path

raw = Path(sys.argv[1])
sub = sys.argv[2]

f = raw / f"sub-{sub}/fmap/sub-{sub}_phasediff.json"

if not f.exists():
    raise FileNotFoundError(f"Missing fieldmap JSON: {f}")

with open(f) as h:
    d = json.load(h)

d["IntendedFor"] = [
    f"bids::sub-{sub}/func/sub-{sub}_task-rest_bold.nii.gz"
]

with open(f, "w") as h:
    json.dump(d, h, indent=4)

print(f"{sub}: fieldmap association OK")
PY

    if [ $? -ne 0 ]; then
        echo "ERROR: Fieldmap setup failed for $SUB"
        exit 1
    fi

    SUBWORK="$WORK/$SUB"
    mkdir -p "$SUBWORK"

    echo "Starting fMRIPrep for $SUB..."

    docker run --rm \
      --platform linux/amd64 \
      -v "$RAW:/data:ro" \
      -v "$OUT:/out" \
      -v "$SUBWORK:/work" \
      -v "$LICENSE:/opt/freesurfer/license.txt:ro" \
      "$IMAGE" \
      /data /out participant \
      --participant-label "$SUB" \
      --task-id rest \
      --output-spaces MNI152NLin2009cAsym:res-2 \
      --fs-license-file /opt/freesurfer/license.txt \
      --fs-no-reconall \
      --nprocs 6 \
      --omp-nthreads 4 \
      --mem-mb 16000 \
      -w /work

    STATUS=$?

    if [ $STATUS -ne 0 ]; then
        echo "ERROR: fMRIPrep failed for $SUB"
        echo "Work directory retained for troubleshooting:"
        echo "$SUBWORK"
        exit 1
    fi

    # Verify final products
    if [ ! -f "$BOLD_OUT" ] || [ ! -f "$CONF_OUT" ] || [ ! -f "$REPORT_OUT" ]; then
        echo "ERROR: Required final output missing for $SUB"
        echo "Work directory retained."
        exit 1
    fi

    echo "$SUB successfully verified."

    # Work cache is safe to remove only AFTER verification
    rm -rf "$SUBWORK"

    echo "$SUB temporary work removed."
    echo "Available disk:"
    df -h "$HOME" | tail -1

done

echo
echo "================================================"
echo "ALL AVAILABLE SUBJECTS FINISHED"
echo "================================================"
