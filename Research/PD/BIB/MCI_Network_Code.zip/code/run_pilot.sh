#!/bin/bash

set -u

PROJECT="$HOME/Research/PD_MCI_Network"
RAW="$PROJECT/raw/ds005892"
OUT="$PROJECT/derivatives"
WORK="$PROJECT/work"
LICENSE="$PROJECT/licenses/license.txt"

SUBJECTS=(
  MJF026 MJF054
  MJF014 MJF020 MJF033
  MJF008 MJF003 MJF068
)

for SUB in "${SUBJECTS[@]}"
do
    echo
    echo "================================================"
    echo "Starting $SUB"
    echo "================================================"

    # Separate work directory for each subject
    SUBWORK="$WORK/$SUB"
    mkdir -p "$SUBWORK"

    docker run --rm \
      --platform linux/amd64 \
      -v "$RAW:/data:ro" \
      -v "$OUT:/out" \
      -v "$SUBWORK:/work" \
      -v "$LICENSE:/opt/freesurfer/license.txt:ro" \
      nipreps/fmriprep:25.2.5 \
      /data /out participant \
      --participant-label "$SUB" \
      --task-id rest \
      --output-spaces MNI152NLin2009cAsym:res-2 \
      --fs-license-file /opt/freesurfer/license.txt \
      --fs-no-reconall \
      --nprocs 6 \
      --omp-nthreads 4 \
      --mem-mb 16000 \
      -w /work

    STATUS=$?

    if [ $STATUS -ne 0 ]; then
        echo "ERROR: fMRIPrep failed for $SUB"
        echo "Stopping pilot."
        exit 1
    fi

    BOLD="$OUT/sub-$SUB/func/sub-${SUB}_task-rest_space-MNI152NLin2009cAsym_res-2_desc-preproc_bold.nii.gz"
    CONF="$OUT/sub-$SUB/func/sub-${SUB}_task-rest_desc-confounds_timeseries.tsv"

    if [ ! -f "$BOLD" ] || [ ! -f "$CONF" ]; then
        echo "ERROR: Expected output missing for $SUB"
        exit 1
    fi

    echo
    echo "$SUB finished successfully."
    echo "Keeping work directory for now:"
    du -sh "$SUBWORK"

done

echo
echo "================================================"
echo "ALL PILOT SUBJECTS FINISHED"
echo "================================================"
