from pathlib import Path
from collections import Counter

import numpy as np
import pandas as pd

P = Path.home() / "Research/PD_MCI_Network"

NBS = P / "results/NBS_PDNC_Control_directional"
CONN = P / "results/connectivity"
OUT = NBS / "component_1_mapping"

OUT.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# Load Schaefer labels
# ------------------------------------------------------------

labels_file = CONN / "schaefer200_labels.txt"

labels = [
    x.strip()
    for x in labels_file.read_text().splitlines()
    if x.strip()
]

if len(labels) != 200:
    raise RuntimeError(
        f"Expected 200 labels, found {len(labels)}"
    )

# ------------------------------------------------------------
# Helper functions
# ------------------------------------------------------------

def get_network(label):

    mapping = {
        "Vis": "Visual",
        "SomMot": "Somatomotor",
        "DorsAttn": "DorsalAttention",
        "SalVentAttn": "SalienceVentralAttention",
        "Limbic": "Limbic",
        "Cont": "Control",
        "Default": "DefaultMode",
    }

    for key, value in mapping.items():
        if f"_{key}_" in label:
            return value

    raise RuntimeError(
        f"Network not recognized: {label}"
    )


def get_hemi(label):

    if "_LH_" in label:
        return "Left"

    if "_RH_" in label:
        return "Right"

    return "Unknown"


network_order = [
    "Visual",
    "Somatomotor",
    "DorsalAttention",
    "SalienceVentralAttention",
    "Limbic",
    "Control",
    "DefaultMode",
]

# ------------------------------------------------------------
# Load significant component
# ------------------------------------------------------------

nodes = np.load(
    NBS / "negative_component_1_nodes.npy"
)

edges = np.load(
    NBS / "negative_component_1_edges.npy"
)

print("Nodes:", len(nodes))
print("Edges:", len(edges))

# ------------------------------------------------------------
# Reconstruct edgewise t statistics
# ------------------------------------------------------------

mats = np.load(
    P / "results/NBS_PDNC_Control/fc_z_matrices.npy"
)

X = np.load(
    P / "results/NBS_PDNC_Control/design_matrix.npy"
)

n, nroi, _ = mats.shape

iu = np.triu_indices(nroi, k=1)

Y = mats[:, iu[0], iu[1]]

group_col = 1

XtX_inv = np.linalg.inv(X.T @ X)

B = XtX_inv @ X.T @ Y

resid = Y - X @ B

df_resid = n - np.linalg.matrix_rank(X)

sigma2 = (
    np.sum(resid ** 2, axis=0)
    / df_resid
)

se_group = np.sqrt(
    sigma2
    * XtX_inv[group_col, group_col]
)

t_values = (
    B[group_col]
    / se_group
)

# Map edge pair -> t and beta
edge_lookup = {}

for k, (i, j) in enumerate(
    zip(iu[0], iu[1])
):
    edge_lookup[(i, j)] = (
        t_values[k],
        B[group_col, k]
    )

# ------------------------------------------------------------
# Node table
# ------------------------------------------------------------

node_rows = []

degree = Counter()

for i, j in edges:
    degree[int(i)] += 1
    degree[int(j)] += 1

for node in nodes:

    node = int(node)

    label = labels[node]

    node_rows.append({
        "ROI_index_0based": node,
        "ROI_number_1based": node + 1,
        "Label": label,
        "Hemisphere": get_hemi(label),
        "Network": get_network(label),
        "Component_degree": degree[node],
    })

node_df = pd.DataFrame(node_rows)

node_df = node_df.sort_values(
    ["Component_degree", "Network"],
    ascending=[False, True]
)

node_df.to_csv(
    OUT / "component_nodes.csv",
    index=False
)

# ------------------------------------------------------------
# Edge table
# ------------------------------------------------------------

edge_rows = []

for i, j in edges:

    i = int(i)
    j = int(j)

    # Stored component edges should be upper triangular.
    key = (
        (i, j)
        if i < j
        else (j, i)
    )

    t, beta = edge_lookup[key]

    label_i = labels[i]
    label_j = labels[j]

    net_i = get_network(label_i)
    net_j = get_network(label_j)

    pair = sorted(
        [net_i, net_j],
        key=lambda x: network_order.index(x)
    )

    network_pair = (
        pair[0] + "__" + pair[1]
    )

    edge_rows.append({
        "ROI1_index": i,
        "ROI2_index": j,
        "ROI1": label_i,
        "ROI2": label_j,
        "Network1": net_i,
        "Network2": net_j,
        "Network_pair": network_pair,
        "Beta_PDNC_minus_Control": beta,
        "t": t,
    })

edge_df = pd.DataFrame(edge_rows)

edge_df["abs_t"] = np.abs(
    edge_df["t"]
)

edge_df = edge_df.sort_values(
    "abs_t",
    ascending=False
)

edge_df.to_csv(
    OUT / "component_edges.csv",
    index=False
)

# ------------------------------------------------------------
# Network composition of nodes
# ------------------------------------------------------------

node_network_counts = (
    node_df["Network"]
    .value_counts()
    .reindex(
        network_order,
        fill_value=0
    )
)

node_network_counts.to_csv(
    OUT / "node_network_counts.csv",
    header=["Nodes"]
)

# ------------------------------------------------------------
# Network-pair composition of edges
# ------------------------------------------------------------

edge_pair_counts = (
    edge_df["Network_pair"]
    .value_counts()
    .reset_index()
)

edge_pair_counts.columns = [
    "Network_pair",
    "Edges"
]

edge_pair_counts.to_csv(
    OUT / "edge_network_pair_counts.csv",
    index=False
)

# ------------------------------------------------------------
# 7x7 edge-count matrix
# ------------------------------------------------------------

count_matrix = pd.DataFrame(
    0,
    index=network_order,
    columns=network_order,
    dtype=int
)

for _, row in edge_df.iterrows():

    a = row["Network1"]
    b = row["Network2"]

    count_matrix.loc[a, b] += 1

    if a != b:
        count_matrix.loc[b, a] += 1

count_matrix.to_csv(
    OUT / "edge_count_matrix_7x7.csv"
)

# ------------------------------------------------------------
# Display
# ------------------------------------------------------------

print("\n==========================================")
print("NODES BY YEO NETWORK")
print("==========================================")

print(node_network_counts)

print("\n==========================================")
print("EDGES BY NETWORK PAIR")
print("==========================================")

print(
    edge_pair_counts.head(20)
    .to_string(index=False)
)

print("\n==========================================")
print("7 x 7 EDGE COUNT MATRIX")
print("==========================================")

print(count_matrix)

print("\n==========================================")
print("TOP 20 STRONGEST REDUCED EDGES")
print("==========================================")

print(
    edge_df[
        [
            "ROI1",
            "ROI2",
            "Network1",
            "Network2",
            "Beta_PDNC_minus_Control",
            "t",
        ]
    ]
    .head(20)
    .round({
        "Beta_PDNC_minus_Control": 4,
        "t": 4
    })
    .to_string(index=False)
)

print("\n==========================================")
print("TOP 20 HUB NODES")
print("==========================================")

print(
    node_df[
        [
            "Label",
            "Hemisphere",
            "Network",
            "Component_degree",
        ]
    ]
    .head(20)
    .to_string(index=False)
)

print("\nSaved to:")
print(OUT)
