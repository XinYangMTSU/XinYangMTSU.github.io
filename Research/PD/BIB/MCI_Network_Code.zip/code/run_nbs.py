from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components

P = Path.home() / "Research/PD_MCI_Network"
NBS = P / "results/NBS"

THRESHOLD = 3.1
N_PERM = 5000
SEED = 20261005

rng = np.random.default_rng(SEED)

# ============================================================
# LOAD DATA
# ============================================================

mats = np.load(NBS / "pd_fc_z_matrices.npy")
X = np.load(NBS / "design_matrix.npy")
subjects = pd.read_csv(NBS / "pd_subjects_covariates.csv")

n, nroi, _ = mats.shape

print("Subjects:", n)
print("ROIs:", nroi)
print("Permutations:", N_PERM)
print("Primary threshold: |t| >", THRESHOLD)

# ============================================================
# VECTORIZE UNIQUE EDGES
# ============================================================

iu = np.triu_indices(nroi, k=1)

Y = mats[:, iu[0], iu[1]]

print("Edges:", Y.shape[1])

# Design:
# 0 intercept
# 1 group: PD-MCI=1
# 2 age
# 3 sex
# 4 FD

group_col = 1

# Reduced model removes group but retains nuisance covariates
X0 = np.delete(X, group_col, axis=1)

# ============================================================
# FAST OLS T-STATISTIC FOR GROUP EFFECT
# ============================================================

XtX_inv = np.linalg.inv(X.T @ X)
B = XtX_inv @ X.T @ Y

resid = Y - X @ B

df_resid = n - np.linalg.matrix_rank(X)

sigma2 = np.sum(resid**2, axis=0) / df_resid

se_group = np.sqrt(
    sigma2 * XtX_inv[group_col, group_col]
)

t_obs = B[group_col] / se_group

print("Residual df:", df_resid)
print("Observed max |t|:", np.max(np.abs(t_obs)))

# ============================================================
# COMPONENT FINDER
# ============================================================

def find_components(t_values, threshold):

    mask = np.abs(t_values) > threshold

    edge_i = iu[0][mask]
    edge_j = iu[1][mask]

    if len(edge_i) == 0:
        return []

    adjacency = np.zeros(
        (nroi, nroi),
        dtype=np.uint8
    )

    adjacency[edge_i, edge_j] = 1
    adjacency[edge_j, edge_i] = 1

    n_components, labels = connected_components(
        csr_matrix(adjacency),
        directed=False,
        return_labels=True
    )

    components = []

    for component_id in range(n_components):

        nodes = np.where(
            labels == component_id
        )[0]

        if len(nodes) < 2:
            continue

        node_mask = np.zeros(nroi, dtype=bool)
        node_mask[nodes] = True

        component_edge_mask = (
            mask
            & node_mask[iu[0]]
            & node_mask[iu[1]]
        )

        edge_indices = np.where(
            component_edge_mask
        )[0]

        if len(edge_indices) == 0:
            continue

        components.append({
            "nodes": nodes,
            "edge_indices": edge_indices,
            "extent": len(edge_indices)
        })

    components.sort(
        key=lambda x: x["extent"],
        reverse=True
    )

    return components

obs_components = find_components(
    t_obs,
    THRESHOLD
)

print("\nObserved suprathreshold components:")

if not obs_components:
    print("None")
else:
    for i, comp in enumerate(obs_components, 1):
        print(
            f"Component {i}: "
            f"{len(comp['nodes'])} nodes, "
            f"{comp['extent']} edges"
        )

# ============================================================
# FREEDMAN-LANE PERMUTATION
#
# Reduced model:
# connectivity ~ age + sex + FD
#
# Permute reduced-model residuals, then refit full model.
# ============================================================

X0_inv = np.linalg.pinv(X0)

B0 = X0_inv @ Y
Yhat0 = X0 @ B0
E0 = Y - Yhat0

max_extent_null = np.zeros(
    N_PERM,
    dtype=int
)

print("\nStarting permutations...")

for p in range(N_PERM):

    perm = rng.permutation(n)

    Yperm = Yhat0 + E0[perm, :]

    Bp = XtX_inv @ X.T @ Yperm

    resid_p = Yperm - X @ Bp

    sigma2_p = (
        np.sum(resid_p**2, axis=0)
        / df_resid
    )

    se_p = np.sqrt(
        sigma2_p
        * XtX_inv[group_col, group_col]
    )

    t_perm = (
        Bp[group_col] / se_p
    )

    comps = find_components(
        t_perm,
        THRESHOLD
    )

    if comps:
        max_extent_null[p] = comps[0]["extent"]

    if (p + 1) % 500 == 0:
        print(
            f"{p + 1}/{N_PERM} permutations complete"
        )

# ============================================================
# COMPONENT-LEVEL FWE P VALUES
# ============================================================

results = []

for i, comp in enumerate(obs_components, 1):

    extent = comp["extent"]

    p_fwe = (
        1
        + np.sum(
            max_extent_null >= extent
        )
    ) / (N_PERM + 1)

    edge_indices = comp["edge_indices"]

    edge_rows = iu[0][edge_indices]
    edge_cols = iu[1][edge_indices]

    component_t = t_obs[edge_indices]

    results.append({
        "Component": i,
        "Nodes": len(comp["nodes"]),
        "Edges": extent,
        "FWE_p": p_fwe,
        "Mean_t": np.mean(component_t),
        "Min_t": np.min(component_t),
        "Max_t": np.max(component_t)
    })

    np.save(
        NBS / f"component_{i}_nodes.npy",
        comp["nodes"]
    )

    np.save(
        NBS / f"component_{i}_edges.npy",
        np.column_stack(
            [edge_rows, edge_cols]
        )
    )

# ============================================================
# SAVE
# ============================================================

np.save(
    NBS / "observed_group_t.npy",
    t_obs
)

np.save(
    NBS / "null_max_component_extent.npy",
    max_extent_null
)

result_df = pd.DataFrame(results)

result_df.to_csv(
    NBS / "nbs_results.csv",
    index=False
)

print("\n======================================")
print("NBS RESULTS")
print("======================================")

if len(result_df) == 0:
    print(
        "No connected component exceeded "
        f"|t| > {THRESHOLD}."
    )
else:
    print(
        result_df.round(4).to_string(
            index=False
        )
    )

    sig = result_df[
        result_df["FWE_p"] < 0.05
    ]

    print(
        "\nFWE-significant components:",
        len(sig)
    )

print("\nNull maximum extent:")
print(
    "Median:",
    np.median(max_extent_null)
)

print(
    "95th percentile:",
    np.percentile(
        max_extent_null,
        95
    )
)

print("\nSaved to:")
print(NBS)
